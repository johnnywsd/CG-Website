
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Matrix m = new Matrix(Cube.vertices);
		m.toHomogeneousMatrix().show();
		System.out.println();
		m.getMaxItemEachRow().show();
		System.out.println();
		m.show();
	}

}
