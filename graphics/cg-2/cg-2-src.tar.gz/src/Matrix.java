/*************************************************************************
 *  Compilation:  javac Matrix.java
 *  Execution:    java Matrix
 *
 *  A bare-bones immutable data type for M-by-N matrices.
 *
 *************************************************************************/

final public class Matrix {
    private final int M;             // number of rows
    private final int N;             // number of columns
    private final double[][] data;   // M-by-N array

    // create M-by-N matrix of 0's
    public Matrix(int M, int N) {
        this.M = M;
        this.N = N;
        data = new double[M][N];
    }

    // create matrix based on 2d array
    public Matrix(double[][] data) {
        M = data.length;
        N = data[0].length;
        this.data = new double[M][N];
        for (int i = 0; i < M; i++)
            for (int j = 0; j < N; j++)
                    this.data[i][j] = data[i][j];
    }

    // copy constructor
    private Matrix(Matrix A) { this(A.data); }
    
    public double[][] getData(){
    	return this.data;
    }
    
    public int getM(){
    	return this.M;
    }
    public int getN(){
    	return this.N;
    }
    
    public double getItem(int m,int n){
    	return data[m][n];
    }
    
    public Matrix getMaxItemEachRow(){
    	double[][]  newData = new double[M][1];
    	for(int i=0;i<M;i++){
    		newData[i][0] = this.data[i][0];
    		for(int j=0; j<N;j++){
    			newData[i][0] = newData[i][0]<this.data[i][j]?this.data[i][j]:newData[i][0];
    		}
    	}
    	return new Matrix(newData);
    }
    
    public Matrix getMinItemEachRow(){
    	double[][]  newData = new double[M][1];
    	for(int i=0;i<M;i++){
    		newData[i][0] = this.data[i][0];
    		for(int j=0; j<N;j++){
    			newData[i][0] = newData[i][0]>this.data[i][j]?this.data[i][j]:newData[i][0];
    		}
    	}
    	return new Matrix(newData);
    }
    /**
     * Get a single column
     * @param col the index of column. The Index begin at 0
     * @return A M*1 Matrix
     */
    public Matrix getCol(int col){
    	double[][] colTmp = new double[M][1];
    	for(int i=0;i<M;i++){
    		colTmp[i][0]=data[i][col];
    	}
    	return new Matrix(colTmp);
    }

//    // create and return a random M-by-N matrix with values between 0 and 1
//    public static Matrix random(int M, int N) {
//        Matrix A = new Matrix(M, N);
//        for (int i = 0; i < M; i++)
//            for (int j = 0; j < N; j++)
//                A.data[i][j] = Math.random();
//        return A;
//    }

    // create and return the N-by-N identity matrix
    public static Matrix identity(int N) {
        Matrix I = new Matrix(N, N);
        for (int i = 0; i < N; i++)
            I.data[i][i] = 1;
        return I;
    }

    // swap rows i and j
    private void swap(int i, int j) {
    	double[] temp = data[i];
        data[i] = data[j];
        data[j] = temp;
    }

    // create and return the transpose of the invoking matrix
    public Matrix transpose() {
        Matrix A = new Matrix(N, M);
        for (int i = 0; i < M; i++)
            for (int j = 0; j < N; j++)
                A.data[j][i] = this.data[i][j];
        return A;
    }

    // return C = A + B
    public Matrix plus(Matrix B) {
        Matrix A = this;
        if (B.M != A.M || B.N != A.N) throw new RuntimeException("Illegal matrix dimensions.");
        Matrix C = new Matrix(M, N);
        for (int i = 0; i < M; i++)
            for (int j = 0; j < N; j++)
                C.data[i][j] = A.data[i][j] + B.data[i][j];
        return C;
    }


    // return C = A - B
    public Matrix minus(Matrix B) {
        Matrix A = this;
        if (B.M != A.M || B.N != A.N) throw new RuntimeException("Illegal matrix dimensions.");
        Matrix C = new Matrix(M, N);
        for (int i = 0; i < M; i++)
            for (int j = 0; j < N; j++)
                C.data[i][j] = A.data[i][j] - B.data[i][j];
        return C;
    }

    // does A = B exactly?
    public boolean eq(Matrix B) {
        Matrix A = this;
        if (B.M != A.M || B.N != A.N) throw new RuntimeException("Illegal matrix dimensions.");
        for (int i = 0; i < M; i++)
            for (int j = 0; j < N; j++)
                if (A.data[i][j] != B.data[i][j]) return false;
        return true;
    }

    // return C = A * B
    public Matrix times(Matrix B) {
        Matrix A = this;
        if (A.N != B.M) throw new RuntimeException("Illegal matrix dimensions.");
        Matrix C = new Matrix(A.M, B.N);
        for (int i = 0; i < C.M; i++)
            for (int j = 0; j < C.N; j++)
                for (int k = 0; k < A.N; k++)
                    C.data[i][j] += (A.data[i][k] * B.data[k][j]);
        return C;
    }
    
    public Matrix scale(int scale){
    	double[][] newData = new double[M][N];
    	for(int i=0;i<M;i++)
    		for(int j=0;j<N;j++){
    			newData[i][j] = scale*data[i][j];
    		}
    	return new Matrix(newData);
    }
    
    public Matrix toHomogeneousMatrix(){
    	double[][] newData = new double[M+1][N];
    	for(int i=0;i<M;i++)
    		for(int j=0;j<N;j++){
    			newData[i][j] = data[i][j];
    		}
    	for(int k=0;k<N;k++){
    		newData[M][k] = 1;
    	}
    	return new Matrix(newData);
    }
    
    public Matrix fromHomogeneousMatrixToNomal(){
    	double[][] newData = new double[M-1][N];
    	for(int i=0;i<M-1;i++)
    		for(int j=0;j<N;j++){
    			newData[i][j] = data[i][j];
    		}
    	return new Matrix(newData);
    }


        
    // print matrix to standard output
    public void show() {
        for (int i = 0; i < M; i++) {
            for (int j = 0; j < N; j++) 
                System.out.printf("%f ", data[i][j]);
            System.out.println();
        }
    }



    // test client
    public static void main(String[] args) {
    	double[][] d = { { 1, 2, 3 }, { 4, 5, 6 }, { 9, 1, 3} };
        Matrix D = new Matrix(d);
        D.show();        
        System.out.println();
    }
}