import java.awt.BasicStroke;
import java.awt.Button;
import java.awt.Color;
import java.awt.Event;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Stroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



public class MyGraph extends BufferedApplet {
	private static final long serialVersionUID = -9176115728277601767L;
	private static final int scale = 170;  
	private int width = 600;
	private int height = 650;
	private int controlPanel_height = 90;
	private double alpha = -1.412;
	private double beta = 2.023;
	private double gamma = 1.936;
	private double moveStep = 10;
	private double moveX = 0;
	private double moveY = 0;
	int count=0;
	
	private Button btnAlpha = new Button("Alpha");
	private Button btnBeta = new Button("Beta");
	private Button btnGamma = new Button("Gamma");
	private Button btnLeft = new Button("Move Left");
	private Button btnRight = new Button("Move Right");
	private Button btnUp = new Button("Move Up");
	private Button btnDown = new Button("Move Down");
	
	private Button btnAlphaAuto = new Button("Alpha");
	private Button btnBetaAuto = new Button("Beta");
	private Button btnGammaAuto = new Button("Gamma");
	private Panel controlPanel = new Panel();
	private Panel subPanel1 = new Panel();
	private Panel subPanel2 = new Panel(); 
	private Panel subPanel3 = new Panel();
	
	private boolean alphaAutoFlag = false;
	private boolean betaAutoFlag = false;
	private boolean gammaAutoFlag = false;
	
	private double rotateStep = Math.PI/36;
	
	double startTime = System.currentTimeMillis() / 1000.0;
	
	int startX = 0;
	int startY =0;
	
	@Override
	public void init(){
		controlPanel.setLayout(new GridLayout(3,1));
		controlPanel.add(subPanel1);
		controlPanel.add(subPanel2);
		controlPanel.add(subPanel3);
		subPanel1.setLayout(new FlowLayout(FlowLayout.LEFT));
		subPanel2.setLayout(new FlowLayout(FlowLayout.LEFT));
		subPanel3.setLayout(new FlowLayout(FlowLayout.LEFT));
		subPanel1.add(new Label("Rotate:"));
		subPanel1.add(btnAlpha);
		subPanel1.add(btnBeta);
		subPanel1.add(btnGamma);
		
		subPanel2.add(new Label("Translate:"));
		subPanel2.add(btnLeft);
		subPanel2.add(btnRight);
		subPanel2.add(btnUp);
		subPanel2.add(btnDown);
		
		subPanel3.add(new Label("Rotate Automatically:"));
		subPanel3.add(btnAlphaAuto);
		subPanel3.add(btnBetaAuto);
		subPanel3.add(btnGammaAuto);
		
		controlPanel.setSize(width, height);
		controlPanel.setBackground(Color.WHITE);
		
		RotateListener rl = new RotateListener();
		btnAlpha.addActionListener(rl);
		btnBeta.addActionListener(rl);
		btnGamma.addActionListener(rl);
		
		RotateAutoListener rla = new RotateAutoListener();
		btnAlphaAuto.addActionListener(rla);
		btnBetaAuto.addActionListener(rla);
		btnGammaAuto.addActionListener(rla);
		
		MoveListener ml = new MoveListener();
		btnLeft.addActionListener(ml);
		btnRight.addActionListener(ml);
		btnUp.addActionListener(ml);
		btnDown.addActionListener(ml);
		
		this.setLayout(null);
		controlPanel.setBounds(0, height-controlPanel_height-10, width-100, controlPanel_height);
		this.add(controlPanel);
	}
	
	public class RotateListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			if(arg0.getSource() == btnAlpha){
				alpha +=rotateStep;
			}else if(arg0.getSource() == btnBeta){
				beta +=rotateStep;
			}else if(arg0.getSource() == btnGamma){
				gamma +=rotateStep;
			}
//			System.out.println(String.format("%f,%f,%f", alpha,beta,gamma));
		}
		
	}
	
	public class RotateAutoListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {


			if(arg0.getSource() == btnAlphaAuto){
				alphaAutoFlag = !alphaAutoFlag;
			}else if(arg0.getSource() == btnBetaAuto){
				betaAutoFlag = !betaAutoFlag;
			}
			else if(arg0.getSource() == btnGammaAuto){
				gammaAutoFlag = !gammaAutoFlag;
			}
		}
		
	}
	public class MoveListener implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent arg0) {
			if(arg0.getSource() == btnLeft){
				moveX -=moveStep;
			}else if(arg0.getSource() == btnRight){
				moveX +=moveStep;
			}else if(arg0.getSource() == btnUp){
				moveY -=moveStep;
			}else if(arg0.getSource() == btnDown){
				moveY +=moveStep;
			}
		}
		
	}
	
	
	public boolean mouseDown(Event e, int x, int y) {
		startX = x;
		startY = y;
		return true;
	}

	int currentX = 0;
	int currentY = 0;
	public boolean mouseDrag(Event e, int x, int y) {
		currentX = x;
		currentY = y;
		alpha = ((double)(-currentX+startX))/60;
		beta = ((double)(-currentY+startY))/60;
		gamma = ((double)(-currentY+startY))/60;
		return true;
	}

	@Override
//	public void render(Graphics g){
//		
//	}
	
	public void render(Graphics g) {
		this.setSize(width,height);
		g.setColor(Color.white);
		g.fillRect(0, 0, width, height);
		g.setColor(Color.BLACK);
		g.setFont(new Font("Courier", Font.ITALIC, 50));
		g.drawString("You can drag!", 10, 70);
		g.setFont(new Font("Courier", Font.ITALIC, 18));
		g.drawString("Or click the buttons below", 130, 100);
		
		// TODO Auto-generated method stub
		
		
		Matrix verticesM = new Matrix(Cube.vertices);
		verticesM = verticesM.scale(scale);
		
		double time = System.currentTimeMillis() / 1000.0 - startTime;
		double rate = 5; 
		if(alphaAutoFlag)
			alpha = time/rate;
		if(betaAutoFlag)
			beta = time/rate;
		if(gammaAutoFlag)
			gamma = time/rate;

		Matrix result = this.getTranformMatrx(alpha, beta, gamma, 300+moveX, 300+moveY, 0).times(verticesM.toHomogeneousMatrix());

		g.setColor(Color.BLACK);
		
		if(count==0){
			result.show();
			count = 4;
		}
//		this.drawCube(result.fromHomogeneousMatrixToNomal(), Cube.conections, g);
		this.drawCube(result, Cube.conections, g);
		
	}
	
	
	private Matrix getTranformMatrx(double alpha,double beta,double gamma, double x, double y,double z){
		double[][] newData = new double[4][4];
		newData[0][0] = Math.cos(alpha)*Math.cos(gamma)-Math.cos(beta)*Math.sin(alpha)*Math.sin(gamma);
		newData[0][1] = -Math.cos(beta)*Math.cos(gamma)*Math.sin(alpha)-Math.cos(alpha)*Math.sin(gamma);
		newData[0][2] = Math.sin(alpha)*Math.sin(beta);
		newData[0][3] = x;
		newData[1][0] = Math.cos(gamma)*Math.sin(alpha)+Math.cos(alpha)*Math.cos(beta)*Math.sin(gamma);
		newData[1][1] = Math.cos(alpha)*Math.cos(beta)*Math.cos(gamma)-Math.sin(alpha)*Math.sin(gamma);
		newData[1][2] = -Math.cos(alpha)*Math.sin(beta);
		newData[1][3] = y;
		newData[2][0] = Math.sin(beta)*Math.sin(gamma);
		newData[2][1] = Math.cos(gamma)*Math.sin(beta);
		newData[2][2] = Math.cos(beta);
		newData[2][3] = z;
		newData[3][0] = 0;
		newData[3][1] = 0;
		newData[3][2] = 0;
		newData[3][3] = 1;
		
		return new Matrix(newData);
	}
	
	private void drawLine(Matrix a, Matrix b,Graphics g){
		if(a.getN()!=1 || b.getN()!=1){
//			System.out.println(a.getM()+" "+b.getN());
			return;
		}
		Graphics2D   g2d   =   (Graphics2D)g;
		Color color = g2d.getColor();
		g2d.setColor(new Color(255,50,50));
		Stroke stroke = g2d.getStroke();
		Stroke bs = new BasicStroke(3f);
		g2d.setStroke(bs);
		g2d.drawLine((int)a.getItem(0, 0), (int)a.getItem(1, 0), (int)b.getItem(0, 0), (int)b.getItem(1, 0));
		g2d.setStroke(stroke);
		g2d.setColor(color);
	}
	
	private void drawDash(Matrix a, Matrix b,Graphics g){
		if(a.getN()!=1 || b.getN()!=1){
//			System.out.println(a.getM()+" "+b.getN());
			return;
		}
		Graphics2D   g2d   =   (Graphics2D)g;
		Color color = g2d.getColor();
		g2d.setColor(Color.GRAY);
		Stroke stroke = g2d.getStroke();
		Stroke bs = new BasicStroke(1, BasicStroke.CAP_BUTT,   
                					BasicStroke.JOIN_BEVEL, 0,   
                					new float[]{10, 4}, 0);
		g2d.setStroke(bs);
		g2d.drawLine((int)a.getItem(0, 0), (int)a.getItem(1, 0), (int)b.getItem(0, 0), (int)b.getItem(1, 0));
		g2d.setStroke(stroke);
		g2d.setColor(color);
		
	}
	
	private void drawCube(Matrix verticesM, int[][] connections,Graphics g){
		if(
				verticesM.getN()!=8 ||
				connections.length!=8 ||
				connections[0].length!=8)
			return;
		
//		Matrix minM = verticesM.getMinItemEachRow();
		double minZ = verticesM.getMinItemEachRow().getItem(2, 0);
//		System.out.println(minZ);
		double e = 0.01;
		for(int i=0;i<8;i++)
			for(int j=0;j<i;j++){
				if(connections[i][j]==1){
					if(Math.abs(verticesM.getItem(2, i)-minZ)<e 
							|| Math.abs(verticesM.getItem(2, j)-minZ)<e){
						this.drawDash(verticesM.getCol(i), verticesM.getCol(j), g);
					}else{
						this.drawLine(verticesM.getCol(i), verticesM.getCol(j), g);
					}
					
				}
					
			}
		
	}


}
