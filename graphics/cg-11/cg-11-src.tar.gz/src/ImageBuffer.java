import java.io.*;
import java.net.*;

import java.awt.*;
import java.awt.image.*;

public class ImageBuffer
{
   public int pixels[] = null, width = 500, height = 340;

   // CONSTRUCT A NEW IMAGE BUFFER BY LOADING FROM A FILE OR URL

   public ImageBuffer(String fileName, java.applet.Applet applet) {

      // GRAB AN IMAGE FROM A URL ON THE WEB OR FROM A FILE ON DISK

      Image image = null;

      try {
         if (fileName.length() >= 4 && fileName.substring(0,5).equals("http:"))
            image = applet.getImage(new URL(fileName));
         else
            image = Toolkit.getDefaultToolkit().getImage(new URL(applet.getCodeBase(),fileName));
      }
      catch (Exception e) { System.err.println(e); }

      // MOVE THE IMAGE INTO AN ARRAY OF PACKED R,G,B PIXELS

      try {
         MediaTracker mt = new MediaTracker(applet);
         mt.addImage(image, 1);
         mt.waitForAll();

         width  = image.getWidth (applet);
         height = image.getHeight(applet);
//         System.out.println("**"+width+" "+height);
         pixels = new int[width * height];

         (new PixelGrabber(image, 0, 0, width, height, pixels, 0, width)).grabPixels();
      }
      catch (InterruptedException e) { }
   }

   // GET THE PACKED R,G,B VALUE AT ONE PIXEL OF THE IMAGE BUFFER

   public int get(int x, int y) { 
//	   System.out.println(x+" "+y);
	   return pixels[x + width * y]; 
   }
   

   // GET A SINGLE COLOR COMPONENT - RED, GREEN OR BLUE - FROM A PIXEL

   public int get(int x, int y, int c) { return get(x, y) >> 16-8*c & 255; }
}
