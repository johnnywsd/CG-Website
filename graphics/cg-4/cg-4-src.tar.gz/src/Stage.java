import java.awt.Color;
import java.awt.Graphics;


public class Stage extends BufferedApplet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7321989914726043131L;
	private static final int width = 500;
	private static final int height = 500;

	@Override
	public void init(){
		this.setSize(width,height);
	}
	
	@Override
	public void render(Graphics g) {
		// TODO Auto-generated method stub
		g.setColor(Color.white);
		g.fillRect(0, 0, width, height);
		g.setColor(Color.BLACK);
		Geometry cube = Geometry.GeometryFactory(Geometry.CYLINDER);
		cube.matrix.scale(200);
		double time = System.currentTimeMillis()/3000.0;
//		double time = 0.5;
		cube.matrix.rotateX(time);
		cube.matrix.rotateY(time);
		cube.matrix.rotateZ(time);
//		cube.drawSkeleton(g,true, 250, 250, 0);
		cube.drawFill(g, true,false);
		
//		Geometry cube2 = Geometry.GeometryFactory(Geometry.GLOBE);
//		cube2.matrix.scale(100);
//		cube2.matrix.rotateX(time);
//		cube2.matrix.rotateY(time);
//		cube2.matrix.rotateZ(time);
//		cube2.drawSkeleton(g, 250, 250, 0);
	}

}
