
class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		test1();
	}
	public static void test2(){
		double[][] data = new double[2][3];
		System.out.println(data.length+" "+ data[0].length);
		data[1] = null;
		System.out.println(data.length+" "+ data[0].length);
	}
	
	public static void test1(){
		Matrix A = new Matrix(4,4);
		A.identity();
//		A.show();
		A.rotateX(Math.PI/4);
		A.toHomogeneousMatrix();
		A.fromHomogeneousMatrix();
		Matrix cube = new Matrix(Cube.vertices);
		Matrix tr = new Matrix(Cube.vertices.length, Cube.vertices[0].length);
		A.transform(cube, tr);
//		A.show();
		tr.show();
//		tr.identity();
		A.show();
		A.identity();
		A.translate(2, 3, 4);
		A.translate(1, 1, 1);
		System.out.println("*****************");
		A.show();
		System.out.println("*****************");
		A.rotateX(Math.PI/4);
		A.show();
		System.out.println("*****************");

	}

}
