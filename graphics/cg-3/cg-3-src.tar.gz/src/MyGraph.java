import java.awt.BasicStroke;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Stroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;



public class MyGraph extends BufferedApplet {
	private static final long serialVersionUID = -9176115728277601767L;
	private static final int scale = 170;  
	private int width = 600;
	private int height = 750;
	private int controlPanel_height = 150;
	private double alpha = 0;
	private double beta = 0;
	private double gamma = 0;
	private double moveStep = 10;
	private double moveX = 0;
	private double moveY = 0;
	int count=0; 
	private int jsScale = 100;
	private Dimension jsSize = new Dimension(100,30);

	private Button btnAlpha = new Button("X-axis");
	private Button btnBeta = new Button("Y-axis");
	private Button btnGamma = new Button("Z-axis");

	private JSListener myChangeLinster = new JSListener();
	private JSlider jsRotateX = new JSlider(-jsScale,jsScale);
	private JSlider jsRotateY = new JSlider(-jsScale,jsScale);
	private JSlider jsRotateZ = new JSlider(-jsScale,jsScale);


	private Button btnLeft = new Button("Move Left");
	private Button btnRight = new Button("Move Right");
	private Button btnUp = new Button("Move Up");
	private Button btnDown = new Button("Move Down");

	private Button btnAlphaAuto = new Button("X-axis");
	private Button btnBetaAuto = new Button("Y-axis");
	private Button btnGammaAuto = new Button("Z-axis");
	private Panel controlPanel = new Panel();
	private Panel subPanel1 = new Panel();
	private Panel subPanel2 = new Panel(); 
	private Panel subPanel3 = new Panel();
	private Panel subPanel4 = new Panel();

	private JSlider jsScaleX = new JSlider(-jsScale,jsScale,50);
	private JSlider jsScaleY = new JSlider(-jsScale,jsScale,50);
	private JSlider jsScaleZ = new JSlider(-jsScale,jsScale,50);

	private boolean alphaAutoFlag = false;
	private boolean betaAutoFlag = false;
	private boolean gammaAutoFlag = false;

	private double rotateStep = Math.PI/36;

	double startTime = System.currentTimeMillis() / 1000.0;

	int startX = 0;
	int startY =0;
	
	Matrix verticesM  = new Matrix(Cube.vertices);;
	Matrix result = new Matrix(Cube.vertices.length, Cube.vertices[0].length);

	@Override
	public void init(){
//		verticesM.scale(scale);

		controlPanel.setLayout(new GridLayout(4,1));
		controlPanel.add(subPanel1);
		controlPanel.add(subPanel2);
		controlPanel.add(subPanel3);
		controlPanel.add(subPanel4);
		subPanel1.setLayout(new FlowLayout(FlowLayout.LEFT));
		subPanel2.setLayout(new FlowLayout(FlowLayout.LEFT));
		subPanel3.setLayout(new FlowLayout(FlowLayout.LEFT));
		subPanel4.setLayout(new FlowLayout(FlowLayout.LEFT));

		subPanel1.add(new Label("Rotate:"));

		jsRotateX.setBorder(BorderFactory.createTitledBorder("X"));
		jsRotateY.setBorder(BorderFactory.createTitledBorder("Y"));
		jsRotateZ.setBorder(BorderFactory.createTitledBorder("Z"));
		jsRotateX.setPreferredSize(jsSize);
		jsRotateY.setPreferredSize(jsSize);
		jsRotateZ.setPreferredSize(jsSize);

		subPanel1.add(jsRotateX);
		subPanel1.add(jsRotateY);
		subPanel1.add(jsRotateZ);
		jsRotateX.addChangeListener(myChangeLinster);
		jsRotateY.addChangeListener(myChangeLinster);
		jsRotateZ.addChangeListener(myChangeLinster);

		//		subPanel1.add(btnAlpha);
		//		subPanel1.add(btnBeta);
		//		subPanel1.add(btnGamma);

		subPanel2.add(new Label("Translate:"));
		subPanel2.add(btnLeft);
		subPanel2.add(btnRight);
		subPanel2.add(btnUp);
		subPanel2.add(btnDown);

		subPanel3.add(new Label("Rotate Automatically:"));
		subPanel3.add(btnAlphaAuto);
		subPanel3.add(btnBetaAuto);
		subPanel3.add(btnGammaAuto);


		subPanel4.add(new Label("Scale"));
		subPanel4.add(jsScaleX);
		subPanel4.add(jsScaleY);
		subPanel4.add(jsScaleZ);
		jsScaleX.setBorder(BorderFactory.createTitledBorder("X"));
		jsScaleY.setBorder(BorderFactory.createTitledBorder("Y"));
		jsScaleZ.setBorder(BorderFactory.createTitledBorder("Z"));
		jsScaleX.setPreferredSize(jsSize);
		jsScaleY.setPreferredSize(jsSize);
		jsScaleZ.setPreferredSize(jsSize);

		//		jsScaleX.setPreferredSize(new Dimension(105,20));
		//		UIDefaults defaults = UIManager.getDefaults();
		//		defaults.put("Slider.thumbHeight", 5); // change height
		//		defaults.put("Slider.thumbWidth", 5); // change width

		controlPanel.setSize(width, height);
		controlPanel.setBackground(Color.WHITE);

		RotateListener rl = new RotateListener();
		btnAlpha.addActionListener(rl);
		btnBeta.addActionListener(rl);
		btnGamma.addActionListener(rl);

		RotateAutoListener rla = new RotateAutoListener();
		btnAlphaAuto.addActionListener(rla);
		btnBetaAuto.addActionListener(rla);
		btnGammaAuto.addActionListener(rla);

		MoveListener ml = new MoveListener();
		btnLeft.addActionListener(ml);
		btnRight.addActionListener(ml);
		btnUp.addActionListener(ml);
		btnDown.addActionListener(ml);

		this.setLayout(null);
		controlPanel.setBounds(0, height-controlPanel_height-10, width-100, controlPanel_height);
		this.add(controlPanel);
	}

	private class JSListener implements ChangeListener{

		@Override
		public void stateChanged(ChangeEvent arg0) {
			// TODO Auto-generated method stub
			JSlider source = (JSlider)arg0.getSource();
			if(source == jsRotateX){
				alpha =(double)source.getValue()/jsScale * Math.PI;
			}else if(source == jsRotateY){
				beta =(double)source.getValue()/jsScale * Math.PI;
			}else if(source == jsRotateZ){
				gamma =(double)source.getValue()/jsScale * Math.PI;
			}
		}

	}

	public class RotateListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			if(arg0.getSource() == btnAlpha){
				alpha +=rotateStep;
			}else if(arg0.getSource() == btnBeta){
				beta +=rotateStep;
			}else if(arg0.getSource() == btnGamma){
				gamma +=rotateStep;
			}
			//			System.out.println(String.format("%f,%f,%f", alpha,beta,gamma));
		}

	}

	public class RotateAutoListener implements ActionListener{


		@Override
		public void actionPerformed(ActionEvent arg0) {

			if(arg0.getSource() == btnAlphaAuto){
				alphaAutoFlag = !alphaAutoFlag;
			}else if(arg0.getSource() == btnBetaAuto){
				betaAutoFlag = !betaAutoFlag;
			}
			else if(arg0.getSource() == btnGammaAuto){
				gammaAutoFlag = !gammaAutoFlag;
			}
		}

	}
	public class MoveListener implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent arg0) {
			if(arg0.getSource() == btnLeft){
				moveX -=moveStep;
			}else if(arg0.getSource() == btnRight){
				moveX +=moveStep;
			}else if(arg0.getSource() == btnUp){
				moveY -=moveStep;
			}else if(arg0.getSource() == btnDown){
				moveY +=moveStep;
			}
		}

	}


	public boolean mouseDown(Event e, int x, int y) {
		startX = x;
		startY = y;

		return true;
	}

	int currentX = 0;
	int currentY = 0;
	public boolean mouseDrag(Event e, int x, int y) {
		currentX = x;
		currentY = y;
		alpha = ((double)(-currentY+startY))/100;
		beta = ((double)(-currentX+startX))/100;
		//		gamma = ((double)(-currentY+startY))/60;
		return true;
	}



	public boolean mouseUp(Event e, int x, int y){
		//		this.verticesM = this.result;
		//		System.out.println("UP");
		return true;
	}

	
	
	private Matrix transM = new Matrix(4,4);
	boolean f = true;
	@Override
	public void render(Graphics g) {

		this.setSize(width,height);
		g.setColor(Color.white);
		g.fillRect(0, 0, width, height);
		g.setColor(Color.BLACK);
		g.setFont(new Font("Courier", Font.ITALIC, 50));
		g.drawString("You can drag!", 10, 70);
		g.setFont(new Font("Courier", Font.ITALIC, 18));
		g.drawString("Or click the buttons below", 130, 100);

		// TODO Auto-generated method stub





		double time = System.currentTimeMillis() / 1000.0 - startTime;
		double rate = 5; 
		if(alphaAutoFlag)
			alpha = time/rate;
		if(betaAutoFlag)
			beta = time/rate;
		if(gammaAutoFlag)
			gamma = time/rate;

		//		Matrix result = this.getTranformMatrx(alpha, beta, gamma, 300+moveX, 300+moveY, 0).times(verticesM.toHomogeneousMatrix());

		//		Matrix result = Transform3D.rotateXYZ(alpha, beta, gamma).times(Transform3D.translate(300+moveX, 300+moveY, 0)).times(verticesM.toHomogeneousMatrix());
		//		Matrix result = Transform3D.rotateXYZ(alpha, beta, gamma)
		//						.times(Transform3D.translate(0, 0, 0))
		//						.times(verticesM.toHomogeneousMatrix());

		double scaleX = (double)jsScaleX.getValue()/jsScale *2;
		double scaleY = (double)jsScaleY.getValue()/jsScale *2;
		double scaleZ = (double)jsScaleZ.getValue()/jsScale *2;


		transM.identity();
		transM.scale(scale);
		transM.scale(scaleX,scaleY,scaleZ);
		transM.rotateZ(gamma);
		transM.rotateY(beta);
		transM.rotateX(alpha);
		transM.translate(300+moveX, 300+moveY, 0);
		transM.transform(verticesM, result);
		
//		result = Transform3D.translate(300+moveX, 300+moveY, 0)
//				.times(Transform3D.rotateXYZ(alpha, beta, gamma))
//				.times(Transform3D.scale(scaleX, scaleY, scaleZ))
//				.times(verticesM.toHomogeneousMatrix())
//				.fromHomogeneousMatrixToNomal();

		g.setColor(Color.BLACK);

		//		this.drawCube(result.fromHomogeneousMatrixToNomal(), Cube.conections, g);
		this.drawCube(result, Cube.conections, g);
		
		if(f){
			transM.show();
			
			result.show();
			f = false;
		}
//		transM.identity();
//		transM.scale(scale);
//		transM.transform(verticesM, result);
//		this.drawCube(result, Cube.conections, g);

	}



	private void drawLine(Matrix a, Matrix b,Graphics g){
		if(a.getN()!=1 || b.getN()!=1){
			//			System.out.println(a.getM()+" "+b.getN());
			return;
		}
		Graphics2D   g2d   =   (Graphics2D)g;
		Color color = g2d.getColor();
		g2d.setColor(new Color(255,50,50));
		Stroke stroke = g2d.getStroke();
		Stroke bs = new BasicStroke(3f);
		g2d.setStroke(bs);
		g2d.drawLine((int)a.get(0, 0), (int)a.get(1, 0), (int)b.get(0, 0), (int)b.get(1, 0));
		g2d.setStroke(stroke);
		g2d.setColor(color);
	}

	private void drawDash(Matrix a, Matrix b,Graphics g){
		if(a.getN()!=1 || b.getN()!=1){
			//			System.out.println(a.getM()+" "+b.getN());
			return;
		}
		Graphics2D   g2d   =   (Graphics2D)g;
		Color color = g2d.getColor();
		g2d.setColor(Color.GRAY);
		Stroke stroke = g2d.getStroke();
		Stroke bs = new BasicStroke(1, BasicStroke.CAP_BUTT,   
				BasicStroke.JOIN_BEVEL, 0,   
				new float[]{10, 4}, 0);
		g2d.setStroke(bs);
		g2d.drawLine((int)a.get(0, 0), (int)a.get(1, 0), (int)b.get(0, 0), (int)b.get(1, 0));
		g2d.setStroke(stroke);
		g2d.setColor(color);

	}

	private void drawCube(Matrix verticesM, int[][] connections,Graphics g){
		if(
				verticesM.getN()!=8 ||
				connections.length!=8 ||
				connections[0].length!=8)
			return;

		//		Matrix minM = verticesM.getMinItemEachRow();
		double minZ = verticesM.getMinItemEachRow().get(2, 0);
		//		System.out.println(minZ);
		double e = 0.01;
		for(int i=0;i<8;i++)
			for(int j=0;j<i;j++){
				if(connections[i][j]==1){
					if(Math.abs(verticesM.get(2, i)-minZ)<e 
							|| Math.abs(verticesM.get(2, j)-minZ)<e){
						this.drawDash(verticesM.getCol(i), verticesM.getCol(j), g);
					}else{
						this.drawLine(verticesM.getCol(i), verticesM.getCol(j), g);
					}

				}

			}

	}


}
